import { MyRoutes } from "./routers/router.jsx";
function App() {
return (
  <MyRoutes /> 
) 
}

export default App;