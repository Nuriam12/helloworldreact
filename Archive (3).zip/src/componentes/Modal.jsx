export const Modal =()=>{
    return (
        <div>hola soy un Modal</div>
    )
}