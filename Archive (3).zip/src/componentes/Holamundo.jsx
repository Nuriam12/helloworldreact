export const HolaMundo = () => {
  return (
    <div className ="bg-red-400 p-4 rounded-2xl">
      <h1 className ="bg-blue-500 p-2 rounded-2xl">Hello</h1>
    </div>
  )
}
export const Wtsp = () => {
  return (
    <div className ="bg-violet-400 p-4 rounded-2xl">
      <h1 className ="bg-white p-6 border-amber-300">Que fue mano</h1>
    </div>
  );
}
export const Saludo = () => {
  return (
    <div>
      <h1>todo bien?</h1>
    </div>
  );
}