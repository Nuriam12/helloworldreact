export const Login = () => {
    return (
    <div className="text-white bg-yellow-800 border p-4 m-2">
        LOGIN
    </div>
    )
}