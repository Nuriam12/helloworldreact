export const Page404 = () => {
    return (
    <div className="text-white bg-red-800 border p-4 m-2">
        404 - PAGE NOT FOUND
    </div>
    )
}