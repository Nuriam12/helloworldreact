export const ConfiguracionPage =()=>{
    return(
        <div className="h-screen bg-amber-300 text-black">
            <span>ConfiguracionPage</span>
        </div>
    )
}